-- Name: Super Battle Golf
-- AppID: 4069520

addappid(4069520)
addappid(4069520,0)
addappid(4069521,0,"7e03356de28c147831a4c06ff74efaa4af6dbeafdfffa371069c5635bd41cf00")
